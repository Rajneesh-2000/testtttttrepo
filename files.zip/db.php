<?php
/**
 * db.php — Database Connection File
 * FreshMart Grocery Shop
 *
 * Uses MySQLi with object-oriented style.
 * Edit the constants below to match your MySQL setup.
 */

// ─── Database Credentials ─────────────────────────────────────────────────────
define('DB_HOST',     'localhost');   // MySQL host (usually localhost)
define('DB_USER',     'grocery_user'); // MySQL username
define('DB_PASS',     'StrongPass@123'); // MySQL password  ← CHANGE THIS
define('DB_NAME',     'grocery_db');  // Database name
define('DB_CHARSET',  'utf8mb4');     // Character set

// ─── Create Connection ────────────────────────────────────────────────────────
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// ─── Set Charset ──────────────────────────────────────────────────────────────
$conn->set_charset(DB_CHARSET);

// ─── Check Connection ─────────────────────────────────────────────────────────
if ($conn->connect_error) {
    // In production, log the error instead of displaying it
    error_log("Database connection failed: " . $conn->connect_error);
    
    // Show a friendly error to the user
    die(json_encode([
        'status'  => 'error',
        'message' => 'Database connection failed. Please try again later.'
    ]));
}
// Connection successful — $conn is now available throughout the app
?>
