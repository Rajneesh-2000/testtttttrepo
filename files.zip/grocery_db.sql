-- ============================================================
-- grocery_db.sql — FreshMart Database Setup Script
-- Run this on your MySQL server to initialize the database.
--
-- Compatible: MySQL 8.0+, MariaDB 10.4+
-- Usage:
--   mysql -u root -p < grocery_db.sql
-- ============================================================

-- ─── Step 1: Create the database ──────────────────────────────────────────────
CREATE DATABASE IF NOT EXISTS grocery_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE grocery_db;

-- ─── Step 2: Create dedicated MySQL user ──────────────────────────────────────
-- Creates a user 'grocery_user'@'localhost' with a strong password.
-- Change 'StrongPass@123' to your own secure password.
CREATE USER IF NOT EXISTS 'grocery_user'@'localhost'
    IDENTIFIED BY 'StrongPass@123';

-- ─── Step 3: Grant privileges to the user ─────────────────────────────────────
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, INDEX
    ON grocery_db.*
    TO 'grocery_user'@'localhost';

FLUSH PRIVILEGES;

-- ─── Step 4: Create users table ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id         INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    name       VARCHAR(100)     NOT NULL,
    email      VARCHAR(100)     NOT NULL,
    password   VARCHAR(255)     NOT NULL,            -- bcrypt hash
    created_at TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_email (email)                      -- prevent duplicate emails
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

-- ─── Step 5: Optional — insert a sample admin user ───────────────────────────
-- Password is 'Admin@1234' — change immediately after testing!
-- Hash generated with: password_hash('Admin@1234', PASSWORD_DEFAULT)
-- You can generate a fresh hash at: https://bcrypt.online/
INSERT IGNORE INTO users (name, email, password) VALUES
(
    'Admin User',
    'admin@freshmart.com',
    '$2y$12$LQv3c1yqBWVHxkd0LQ1Lgem0pT/CwCDNOxFgwi8QXKLefGfJOLjXm'
);

-- ─── Verification queries (run manually to confirm) ───────────────────────────
-- SELECT * FROM users;
-- SHOW TABLES;
-- DESCRIBE users;

-- ─── End of setup ─────────────────────────────────────────────────────────────
SELECT 'FreshMart database setup complete!' AS status;
