<?php
/**
 * register.php — User Registration Page
 * Handles form display and POST submission with validation.
 * Passwords are hashed using PHP's password_hash() before storing.
 */

session_start();

// If already logged in, redirect to homepage
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'db.php';  // Load database connection

// ─── Variables ────────────────────────────────────────────────────────────────
$errors  = [];
$success = '';
$name    = $email = '';  // Preserve form values on error

// ─── Handle POST Submission ───────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Sanitize inputs (trim whitespace, strip tags)
    $name     = trim(strip_tags($_POST['name']     ?? ''));
    $email    = trim(strip_tags($_POST['email']    ?? ''));
    $password = trim($_POST['password']            ?? '');
    $confirm  = trim($_POST['confirm_password']    ?? '');

    // ── Validation ──────────────────────────────────────────────────────────
    if (empty($name)) {
        $errors[] = 'Full name is required.';
    } elseif (strlen($name) < 2 || strlen($name) > 100) {
        $errors[] = 'Name must be between 2 and 100 characters.';
    }

    if (empty($email)) {
        $errors[] = 'Email address is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }

    if (empty($password)) {
        $errors[] = 'Password is required.';
    } elseif (strlen($password) < 8) {
        $errors[] = 'Password must be at least 8 characters long.';
    } elseif (!preg_match('/[A-Z]/', $password)) {
        $errors[] = 'Password must contain at least one uppercase letter.';
    } elseif (!preg_match('/[0-9]/', $password)) {
        $errors[] = 'Password must contain at least one number.';
    }

    if ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    // ── Check if email already exists (prepared statement to prevent SQL injection) ──
    if (empty($errors)) {
        $check_stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check_stmt->bind_param('s', $email);
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows > 0) {
            $errors[] = 'An account with this email already exists. <a href="login.php">Login instead?</a>';
        }
        $check_stmt->close();
    }

    // ── Insert user into database ────────────────────────────────────────────
    if (empty($errors)) {
        // Hash password using bcrypt (PASSWORD_DEFAULT)
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $insert_stmt = $conn->prepare(
            "INSERT INTO users (name, email, password) VALUES (?, ?, ?)"
        );
        $insert_stmt->bind_param('sss', $name, $email, $hashed_password);

        if ($insert_stmt->execute()) {
            // Registration successful — auto-login the user
            $_SESSION['user_id']   = $insert_stmt->insert_id;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email']= $email;

            // Redirect to homepage with success flash
            $_SESSION['flash_success'] = 'Welcome, ' . htmlspecialchars($name) . '! Your account has been created.';
            header('Location: index.php');
            exit;
        } else {
            $errors[] = 'Registration failed. Please try again. (DB error)';
        }
        $insert_stmt->close();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account — FreshMart</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🛒</text></svg>">
</head>
<body>

<!-- ════════════════════════════════════════════════════
     AUTH PAGE LAYOUT — Split: visual left, form right
     ════════════════════════════════════════════════════ -->
<div class="auth-page">

    <!-- Left visual panel -->
    <div class="auth-visual">
        <div class="auth-visual-content">
            <span class="auth-visual-emoji">🌿</span>
            <h2>Join FreshMart<br>Today</h2>
            <p>Create your free account and enjoy fresh groceries delivered to your door, every day.</p>

            <!-- Perk items -->
            <div class="auth-visual-perks">
                <div class="perk-item">
                    <span class="perk-icon">🚀</span>
                    <span>Free delivery on your first 3 orders</span>
                </div>
                <div class="perk-item">
                    <span class="perk-icon">💳</span>
                    <span>Earn loyalty points on every purchase</span>
                </div>
                <div class="perk-item">
                    <span class="perk-icon">🔔</span>
                    <span>Get notified of weekly deals & flash sales</span>
                </div>
                <div class="perk-item">
                    <span class="perk-icon">🛡️</span>
                    <span>Secure checkout, hassle-free returns</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Right form panel -->
    <div class="auth-form-area">
        <div class="auth-form-box">

            <!-- Logo back link -->
            <a href="index.php" class="form-logo">
                <div class="logo-icon" style="width:34px;height:34px;background:var(--green-dark);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1rem;">🛒</div>
                FreshMart
            </a>

            <h1>Create Account</h1>
            <p class="subtitle">
                Already have an account?
                <a href="login.php">Log in here</a>
            </p>

            <!-- ── Error messages ── -->
            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <span class="alert-icon">⚠️</span>
                    <div>
                        <?php if (count($errors) === 1): ?>
                            <?= $errors[0] ?>
                        <?php else: ?>
                            <strong>Please fix the following:</strong>
                            <ul style="margin-top:6px;padding-left:16px;">
                                <?php foreach ($errors as $err): ?>
                                    <li><?= $err ?></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- ── Registration Form ── -->
            <form method="POST" action="register.php" novalidate id="registerForm">

                <!-- Full Name -->
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <div class="input-wrap">
                        <span class="input-icon">👤</span>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            placeholder="John Smith"
                            value="<?= htmlspecialchars($name) ?>"
                            autocomplete="name"
                            required
                            class="<?= in_array('Full name is required.', $errors) ? 'error' : '' ?>"
                        >
                    </div>
                </div>

                <!-- Email -->
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <div class="input-wrap">
                        <span class="input-icon">✉️</span>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            placeholder="john@example.com"
                            value="<?= htmlspecialchars($email) ?>"
                            autocomplete="email"
                            required
                            class="<?= in_array('Email address is required.', $errors) ? 'error' : '' ?>"
                        >
                    </div>
                </div>

                <!-- Password -->
                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-wrap">
                        <span class="input-icon">🔒</span>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Min. 8 characters"
                            autocomplete="new-password"
                            required
                        >
                    </div>
                    <p class="password-hint">Must be 8+ characters, include a number and uppercase letter.</p>
                </div>

                <!-- Confirm Password -->
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <div class="input-wrap">
                        <span class="input-icon">🔒</span>
                        <input
                            type="password"
                            id="confirm_password"
                            name="confirm_password"
                            placeholder="Repeat your password"
                            autocomplete="new-password"
                            required
                        >
                    </div>
                </div>

                <!-- Terms checkbox -->
                <div style="margin-bottom:20px;">
                    <label style="display:flex;align-items:flex-start;gap:10px;cursor:pointer;font-size:0.85rem;color:var(--text-mid);">
                        <input type="checkbox" name="terms" required style="width:auto;margin-top:3px;accent-color:var(--green-dark);">
                        I agree to the <a href="#" style="color:var(--green-mid);font-weight:600;">Terms of Service</a>
                        and <a href="#" style="color:var(--green-mid);font-weight:600;">Privacy Policy</a>
                    </label>
                </div>

                <!-- Submit -->
                <button type="submit" class="form-submit-btn">
                    🌱 Create My Account
                </button>

            </form>

        </div>
    </div>
</div>

<script>
// ── Live password match validation ─────────────────────────────────────────────
const pwd = document.getElementById('password');
const confirm = document.getElementById('confirm_password');

function checkMatch() {
    if (confirm.value && pwd.value !== confirm.value) {
        confirm.classList.add('error');
    } else {
        confirm.classList.remove('error');
    }
}
pwd.addEventListener('input', checkMatch);
confirm.addEventListener('input', checkMatch);

// ── Client-side form check before submit ───────────────────────────────────────
document.getElementById('registerForm').addEventListener('submit', function(e) {
    const termsCheck = document.querySelector('input[name="terms"]');
    if (!termsCheck.checked) {
        e.preventDefault();
        alert('Please accept the Terms of Service to continue.');
    }
});
</script>
</body>
</html>
