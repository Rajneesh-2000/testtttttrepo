# 🛒 FreshMart Grocery Shop — Setup Instructions
**Platform:** Amazon Linux 2023 · Apache · PHP 8 · MySQL

---

## 📁 Project Folder Structure

```
/var/www/html/grocery-shop/
├── index.php          ← Homepage (hero, products, footer)
├── register.php       ← User registration form + PHP logic
├── login.php          ← Login form + PHP session logic
├── logout.php         ← Session destroy + redirect
├── users.php          ← Admin: view all registered users
├── db.php             ← Database connection (edit credentials here)
├── style.css          ← All CSS styles
└── grocery_db.sql     ← SQL: creates DB, user, and table
```

---

## ⚙️ Step-by-Step Setup on AWS EC2 (Amazon Linux 2023)

### Step 1 — Launch EC2 Instance

1. Go to **AWS Console → EC2 → Launch Instance**
2. Choose **Amazon Linux 2023 AMI**
3. Instance type: **t2.micro** (free tier eligible)
4. Security Group — add inbound rules:
   - **SSH** — port 22 (your IP)
   - **HTTP** — port 80 (0.0.0.0/0)
   - **HTTPS** — port 443 (optional)
5. Create or select a key pair (.pem file)
6. Launch the instance

---

### Step 2 — Connect to EC2

```bash
# From your local machine (replace with your key and public IP)
chmod 400 your-key.pem
ssh -i your-key.pem ec2-user@YOUR_EC2_PUBLIC_IP
```

---

### Step 3 — Install Apache, PHP 8, and MySQL

```bash
# Update system packages
sudo dnf update -y

# Install Apache web server
sudo dnf install -y httpd

# Install PHP 8.2 and required extensions
sudo dnf install -y php php-mysqlnd php-fpm php-mbstring php-xml php-json

# Install MySQL 8 (community edition)
sudo dnf install -y mysql-server

# Verify versions
php --version
mysql --version
httpd -v
```

---

### Step 4 — Start and Enable Services

```bash
# Start Apache and enable on boot
sudo systemctl start httpd
sudo systemctl enable httpd

# Start MySQL and enable on boot
sudo systemctl start mysqld
sudo systemctl enable mysqld

# Check status
sudo systemctl status httpd
sudo systemctl status mysqld
```

---

### Step 5 — Secure MySQL Installation

```bash
# Run the secure setup wizard
sudo mysql_secure_installation
```

**Follow the prompts:**
- Set root password: `YES` → choose a strong password
- Remove anonymous users: `YES`
- Disallow root login remotely: `YES`
- Remove test database: `YES`
- Reload privilege tables: `YES`

---

### Step 6 — Set Up the Database

```bash
# Log in to MySQL as root
sudo mysql -u root -p

# Inside MySQL, run the SQL setup:
source /var/www/html/grocery-shop/grocery_db.sql;

# OR run directly from shell:
sudo mysql -u root -p < /var/www/html/grocery-shop/grocery_db.sql
```

**This will create:**
- Database: `grocery_db`
- User: `grocery_user` with password `StrongPass@123`
- Table: `users`

---

### Step 7 — Upload Project Files to EC2

**Option A — SCP (from local machine):**
```bash
# Upload the entire folder
scp -i your-key.pem -r ./grocery-shop ec2-user@YOUR_EC2_PUBLIC_IP:/tmp/

# Move to web root
sudo mv /tmp/grocery-shop /var/www/html/
```

**Option B — Create files directly on server:**
```bash
sudo mkdir -p /var/www/html/grocery-shop
cd /var/www/html/grocery-shop
# Then paste each file's content using nano or vim
sudo nano index.php
sudo nano db.php
# ... etc
```

---

### Step 8 — Configure db.php

Edit the database credentials in `db.php`:

```bash
sudo nano /var/www/html/grocery-shop/db.php
```

Update these lines to match your setup:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'grocery_user');
define('DB_PASS', 'StrongPass@123');  // ← change this!
define('DB_NAME', 'grocery_db');
```

---

### Step 9 — Set File Permissions

```bash
# Set ownership to Apache user
sudo chown -R apache:apache /var/www/html/grocery-shop

# Set directory permissions (755) and file permissions (644)
sudo find /var/www/html/grocery-shop -type d -exec chmod 755 {} \;
sudo find /var/www/html/grocery-shop -type f -exec chmod 644 {} \;
```

---

### Step 10 — Configure Apache

```bash
# Enable mod_rewrite (for clean URLs later)
sudo nano /etc/httpd/conf/httpd.conf
```

Find the `<Directory "/var/www/html">` block and set:
```apache
AllowOverride All
```

Then restart Apache:
```bash
sudo systemctl restart httpd
```

---

### Step 11 — Test the Application

Open your browser and navigate to:

| Page | URL |
|------|-----|
| Homepage | `http://YOUR_EC2_PUBLIC_IP/grocery-shop/` |
| Register | `http://YOUR_EC2_PUBLIC_IP/grocery-shop/register.php` |
| Login | `http://YOUR_EC2_PUBLIC_IP/grocery-shop/login.php` |
| Users | `http://YOUR_EC2_PUBLIC_IP/grocery-shop/users.php` |

---

## 🔧 Troubleshooting

### Apache won't start
```bash
sudo systemctl status httpd
sudo journalctl -xe | grep httpd
```

### PHP errors showing on page
```bash
# Check error log
sudo tail -f /var/log/httpd/error_log
```

### Database connection failed
```bash
# Test MySQL connection manually
mysql -u grocery_user -p grocery_db
# If it fails, re-run the SQL setup file
```

### Permission denied errors
```bash
sudo chown -R apache:apache /var/www/html/grocery-shop
sudo chmod -R 755 /var/www/html/grocery-shop
```

### SELinux blocking Apache (Amazon Linux)
```bash
# Check SELinux status
getenforce

# If 'Enforcing', allow Apache to connect to DB:
sudo setsebool -P httpd_can_network_connect_db 1
```

---

## 🔐 Security Checklist (Before Going Live)

- [ ] Change `DB_PASS` in `db.php` to a strong unique password
- [ ] Change MySQL root password
- [ ] Change `grocery_user` password and update `db.php`
- [ ] Remove the demo hint box in `login.php`
- [ ] Protect `users.php` with admin authentication
- [ ] Add HTTPS using Let's Encrypt: `sudo certbot --apache`
- [ ] Move `db.php` above web root if possible
- [ ] Enable PHP error logging (disable display_errors in php.ini)
- [ ] Add rate limiting / CAPTCHA to login and register forms

---

## 📦 Quick Reference Commands

```bash
# Restart Apache
sudo systemctl restart httpd

# Restart MySQL
sudo systemctl restart mysqld

# View Apache error log
sudo tail -100 /var/log/httpd/error_log

# Check open ports
sudo ss -tlnp | grep -E '80|3306'

# MySQL quick login
sudo mysql -u root -p
```

---

## 🗄️ Database Schema

```sql
CREATE TABLE users (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name       VARCHAR(100) NOT NULL,
    email      VARCHAR(100) NOT NULL,
    password   VARCHAR(255) NOT NULL,       -- bcrypt hash
    created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_email (email)
);
```

---

*FreshMart Grocery Shop — Built with PHP 8 + MySQL + Apache on Amazon Linux 2023*
