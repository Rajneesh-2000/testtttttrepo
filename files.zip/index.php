<?php
/**
 * index.php — FreshMart Grocery Shop Homepage
 * Displays: Navbar, Hero (with hostname), Categories, Products, Promo, Features, Footer
 */

// ─── Get Server Hostname ───────────────────────────────────────────────────────
$hostname   = gethostname();              // Server hostname via PHP
$server_ip  = $_SERVER['SERVER_ADDR'] ?? 'N/A';
$php_version = phpversion();

// ─── Session for login state ──────────────────────────────────────────────────
session_start();
$logged_in   = isset($_SESSION['user_id']);
$user_name   = $logged_in ? htmlspecialchars($_SESSION['user_name']) : '';

// ─── Sample Product Data (in real app, this would come from DB) ────────────────
$products = [
    ['id'=>1, 'name'=>'Organic Avocados',   'category'=>'Fruits',    'emoji'=>'🥑', 'price'=>'3.49', 'original'=>'4.99', 'unit'=>'/each',  'weight'=>'Pack of 3', 'rating'=>4.8, 'reviews'=>124, 'badge'=>'Organic',  'badge_type'=>'tag-green'],
    ['id'=>2, 'name'=>'Fresh Strawberries', 'category'=>'Fruits',    'emoji'=>'🍓', 'price'=>'4.99', 'original'=>'',     'unit'=>'/punnet','weight'=>'400g',      'rating'=>4.9, 'reviews'=>289, 'badge'=>'Fresh',    'badge_type'=>'tag-green'],
    ['id'=>3, 'name'=>'Baby Spinach',        'category'=>'Vegetables','emoji'=>'🥬', 'price'=>'2.49', 'original'=>'3.49', 'unit'=>'/bag',   'weight'=>'200g',      'rating'=>4.7, 'reviews'=>97,  'badge'=>'Sale',     'badge_type'=>'tag-orange'],
    ['id'=>4, 'name'=>'Whole Milk',          'category'=>'Dairy',     'emoji'=>'🥛', 'price'=>'1.89', 'original'=>'',     'unit'=>'/bottle','weight'=>'1 Litre',   'rating'=>4.6, 'reviews'=>203, 'badge'=>'',         'badge_type'=>''],
    ['id'=>5, 'name'=>'Free Range Eggs',     'category'=>'Dairy',     'emoji'=>'🥚', 'price'=>'3.29', 'original'=>'3.99', 'unit'=>'/box',   'weight'=>'12 Eggs',   'rating'=>4.9, 'reviews'=>511, 'badge'=>'Popular',  'badge_type'=>'tag-yellow'],
    ['id'=>6, 'name'=>'Sourdough Bread',     'category'=>'Bakery',    'emoji'=>'🍞', 'price'=>'2.99', 'original'=>'',     'unit'=>'/loaf',  'weight'=>'800g',      'rating'=>4.8, 'reviews'=>178, 'badge'=>'Fresh',    'badge_type'=>'tag-green'],
    ['id'=>7, 'name'=>'Atlantic Salmon',     'category'=>'Seafood',   'emoji'=>'🐟', 'price'=>'8.99', 'original'=>'10.99','unit'=>'/fillet','weight'=>'300g',      'rating'=>4.7, 'reviews'=>89,  'badge'=>'Sale',     'badge_type'=>'tag-orange'],
    ['id'=>8, 'name'=>'Cherry Tomatoes',     'category'=>'Vegetables','emoji'=>'🍅', 'price'=>'2.19', 'original'=>'',     'unit'=>'/punnet','weight'=>'300g',      'rating'=>4.5, 'reviews'=>156, 'badge'=>'',         'badge_type'=>''],
];

// ─── Category list ─────────────────────────────────────────────────────────────
$categories = [
    ['emoji'=>'🛒','name'=>'All Items'],
    ['emoji'=>'🍎','name'=>'Fruits'],
    ['emoji'=>'🥦','name'=>'Vegetables'],
    ['emoji'=>'🥩','name'=>'Meat'],
    ['emoji'=>'🐟','name'=>'Seafood'],
    ['emoji'=>'🥛','name'=>'Dairy'],
    ['emoji'=>'🍞','name'=>'Bakery'],
    ['emoji'=>'🌾','name'=>'Grains'],
    ['emoji'=>'🥤','name'=>'Beverages'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshMart — Your Online Grocery Store</title>
    <meta name="description" content="Shop fresh groceries online. Daily delivery, organic produce, great prices.">
    <link rel="stylesheet" href="style.css">
    <!-- Favicon (emoji) -->
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🛒</text></svg>">
</head>
<body>

<!-- ════════════════════════════════════════════════════
     HOSTNAME BANNER — shows server info via PHP
     ════════════════════════════════════════════════════ -->
<div class="hostname-bar">
    🖥️ Served from: <code><?= htmlspecialchars($hostname) ?></code>
    &nbsp;|&nbsp; IP: <code><?= htmlspecialchars($server_ip) ?></code>
    &nbsp;|&nbsp; PHP <code><?= htmlspecialchars($php_version) ?></code>
</div>

<!-- ════════════════════════════════════════════════════
     NAVBAR
     ════════════════════════════════════════════════════ -->
<header class="navbar">
    <div class="container">
        <div class="navbar-inner">
            <!-- Logo -->
            <a href="index.php" class="navbar-logo">
                <div class="logo-icon">🛒</div>
                FreshMart
            </a>

            <!-- Navigation links -->
            <nav class="navbar-nav">
                <a href="index.php" class="active">Home</a>
                <a href="#products">Shop</a>
                <a href="#categories">Categories</a>
                <a href="users.php">Users</a>
                <a href="#contact">Contact</a>
            </nav>

            <!-- Right-side actions -->
            <div class="navbar-actions">
                <!-- Cart button with badge -->
                <button class="cart-btn" title="Shopping Cart" onclick="alert('Cart feature — connect to DB to enable!')">
                    🛒
                    <span class="cart-badge">0</span>
                </button>

                <?php if ($logged_in): ?>
                    <!-- Logged-in state -->
                    <span style="font-size:0.9rem;color:var(--green-mid);font-weight:600;">
                        👋 <?= $user_name ?>
                    </span>
                    <a href="logout.php" class="btn btn-outline">Logout</a>
                <?php else: ?>
                    <a href="login.php" class="btn btn-outline">Login</a>
                    <a href="register.php" class="btn btn-primary">Sign Up</a>
                <?php endif; ?>
            </div>

            <!-- Mobile hamburger -->
            <button class="hamburger" id="hamburgerBtn" aria-label="Open menu">
                <span></span><span></span><span></span>
            </button>
        </div>
    </div>
</header>

<!-- ════════════════════════════════════════════════════
     HERO SECTION
     ════════════════════════════════════════════════════ -->
<section class="hero">
    <div class="container">
        <div class="hero-inner">
            <!-- Hero text -->
            <div class="hero-text">
                <div class="hero-badge">
                    <span class="dot"></span>
                    Free delivery over $50
                </div>

                <h1>
                    Fresh Groceries<br>
                    <span>Delivered to</span><br>
                    Your Door 🚚
                </h1>

                <p>
                    Shop thousands of fresh, organic, and everyday grocery items.
                    Delivered same-day or next-day to your doorstep. Freshness guaranteed.
                </p>

                <div class="hero-cta">
                    <a href="#products" class="btn btn-accent">🛒 Shop Now</a>
                    <a href="register.php" class="btn btn-outline" style="color:#fff;border-color:rgba(255,255,255,0.4);">Create Account</a>
                </div>

                <!-- Stats row -->
                <div class="hero-stats">
                    <div class="stat-item">
                        <div class="stat-number">5,000+</div>
                        <div class="stat-label">Products</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">50k+</div>
                        <div class="stat-label">Happy Customers</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">4.9★</div>
                        <div class="stat-label">App Rating</div>
                    </div>
                </div>
            </div>

            <!-- Hero visual cards -->
            <div class="hero-visual">
                <div class="hero-card-grid">
                    <!-- Featured card -->
                    <div class="hero-mini-card featured">
                        <div class="emoji">🥗</div>
                        <div>
                            <h4>Today's Fresh Pick</h4>
                            <p>Organic salad greens — just harvested</p>
                        </div>
                    </div>
                    <!-- Mini cards -->
                    <div class="hero-mini-card">
                        <div class="emoji">🍊</div>
                        <h4>Citrus Bundle</h4>
                        <p>From $3.99</p>
                    </div>
                    <div class="hero-mini-card">
                        <div class="emoji">🥩</div>
                        <h4>Prime Cuts</h4>
                        <p>From $12.99</p>
                    </div>
                    <div class="hero-mini-card">
                        <div class="emoji">🧀</div>
                        <h4>Artisan Dairy</h4>
                        <p>From $4.49</p>
                    </div>
                    <div class="hero-mini-card">
                        <div class="emoji">🥐</div>
                        <h4>Bakery Fresh</h4>
                        <p>Baked daily</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ════════════════════════════════════════════════════
     CATEGORIES STRIP
     ════════════════════════════════════════════════════ -->
<section class="categories-strip" id="categories">
    <div class="container">
        <div class="categories-scroll">
            <?php foreach ($categories as $i => $cat): ?>
                <button class="cat-chip <?= $i === 0 ? 'active' : '' ?>"
                        onclick="filterProducts('<?= htmlspecialchars($cat['name']) ?>', this)">
                    <span class="cat-emoji"><?= $cat['emoji'] ?></span>
                    <?= htmlspecialchars($cat['name']) ?>
                </button>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ════════════════════════════════════════════════════
     PRODUCTS SECTION
     ════════════════════════════════════════════════════ -->
<section class="products-section" id="products">
    <div class="container">

        <!-- Section header -->
        <div class="section-header">
            <div>
                <h2 class="section-title">Today's Fresh Picks</h2>
                <p class="section-subtitle">Hand-selected fresh produce & groceries</p>
            </div>
            <a href="#" class="btn btn-outline">View All Products</a>
        </div>

        <!-- Products grid -->
        <div class="products-grid" id="productsGrid">
            <?php foreach ($products as $product): ?>
            <div class="product-card" data-category="<?= htmlspecialchars($product['category']) ?>">

                <!-- Product image area -->
                <div class="product-image-wrap">
                    <?php if ($product['badge']): ?>
                        <div class="product-badge">
                            <span class="tag <?= $product['badge_type'] ?>">
                                <?= htmlspecialchars($product['badge']) ?>
                            </span>
                        </div>
                    <?php endif; ?>

                    <button class="wishlist-btn" title="Add to wishlist" onclick="toggleWishlist(this)">❤️</button>
                    <span class="product-emoji"><?= $product['emoji'] ?></span>
                </div>

                <!-- Product info -->
                <div class="product-info">
                    <div class="product-category"><?= htmlspecialchars($product['category']) ?></div>
                    <h3 class="product-name"><?= htmlspecialchars($product['name']) ?></h3>
                    <div class="product-weight"><?= htmlspecialchars($product['weight']) ?></div>

                    <!-- Star rating -->
                    <div class="product-rating">
                        <span class="stars">★★★★<?= $product['rating'] >= 4.8 ? '★' : '☆' ?></span>
                        <span class="rating-count">(<?= $product['reviews'] ?>)</span>
                    </div>

                    <!-- Price & cart -->
                    <div class="product-footer">
                        <div class="product-price">
                            <span class="price-current">$<?= htmlspecialchars($product['price']) ?></span>
                            <span class="price-unit"><?= htmlspecialchars($product['unit']) ?></span>
                            <?php if ($product['original']): ?>
                                <span class="price-original">$<?= htmlspecialchars($product['original']) ?></span>
                            <?php endif; ?>
                        </div>

                        <button class="add-to-cart"
                                title="Add to cart"
                                onclick="addToCart(<?= $product['id'] ?>, '<?= addslashes($product['name']) ?>', this)">
                            +
                        </button>
                    </div>
                </div>

            </div>
            <?php endforeach; ?>
        </div>

        <!-- Promo Banner (inside products section for spacing) -->
        <div style="margin-top: 64px;">
            <div class="promo-banner">
                <div class="promo-content">
                    <h3>🌱 Fresh Organic Box<br>20% Off This Week</h3>
                    <p>Curated seasonal organic produce delivered to your door. No subscription needed.</p>
                </div>
                <a href="#" class="btn btn-white">Claim Offer →</a>
            </div>
        </div>

    </div>
</section>

<!-- ════════════════════════════════════════════════════
     FEATURES STRIP
     ════════════════════════════════════════════════════ -->
<section class="features-strip">
    <div class="container">
        <div class="features-grid">
            <div class="feature-item">
                <span class="feature-icon">🚀</span>
                <h4>Same-Day Delivery</h4>
                <p>Order before 2pm for same-day delivery to your home.</p>
            </div>
            <div class="feature-item">
                <span class="feature-icon">🌿</span>
                <h4>100% Organic Options</h4>
                <p>Hundreds of certified organic products available.</p>
            </div>
            <div class="feature-item">
                <span class="feature-icon">💰</span>
                <h4>Best Price Guarantee</h4>
                <p>We match any local grocery store price — or better.</p>
            </div>
            <div class="feature-item">
                <span class="feature-icon">🔄</span>
                <h4>Easy Returns</h4>
                <p>Not happy? Get a full refund, no questions asked.</p>
            </div>
        </div>
    </div>
</section>

<!-- ════════════════════════════════════════════════════
     FOOTER
     ════════════════════════════════════════════════════ -->
<footer id="contact">
    <div class="container">
        <div class="footer-top">
            <!-- Brand column -->
            <div class="footer-brand">
                <div class="navbar-logo" style="color:#fff;">
                    <div class="logo-icon">🛒</div>
                    FreshMart
                </div>
                <p>
                    Your neighbourhood grocery store, now online.
                    Fresh produce, great prices, and fast delivery
                    right to your door since 2024.
                </p>
                <div class="footer-social">
                    <a href="#" class="social-link">𝕏</a>
                    <a href="#" class="social-link">f</a>
                    <a href="#" class="social-link">in</a>
                    <a href="#" class="social-link">📷</a>
                </div>
            </div>

            <!-- Shop links -->
            <div class="footer-col">
                <h5>Shop</h5>
                <ul>
                    <li><a href="#">Fresh Produce</a></li>
                    <li><a href="#">Dairy & Eggs</a></li>
                    <li><a href="#">Meat & Seafood</a></li>
                    <li><a href="#">Bakery</a></li>
                    <li><a href="#">Beverages</a></li>
                    <li><a href="#">Organic Range</a></li>
                </ul>
            </div>

            <!-- Account links -->
            <div class="footer-col">
                <h5>Account</h5>
                <ul>
                    <li><a href="register.php">Register</a></li>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="users.php">Users</a></li>
                    <li><a href="#">My Orders</a></li>
                    <li><a href="#">Wishlist</a></li>
                </ul>
            </div>

            <!-- Help links -->
            <div class="footer-col">
                <h5>Help</h5>
                <ul>
                    <li><a href="#">Delivery Info</a></li>
                    <li><a href="#">Returns Policy</a></li>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                </ul>
            </div>
        </div>

        <!-- Footer bottom bar -->
        <div class="footer-bottom">
            <p>
                © <?= date('Y') ?> FreshMart. All rights reserved.
                Running on <strong><?= htmlspecialchars($hostname) ?></strong>.
            </p>
            <div class="payment-badges">
                <span class="pay-badge">VISA</span>
                <span class="pay-badge">MC</span>
                <span class="pay-badge">AMEX</span>
                <span class="pay-badge">PayPal</span>
            </div>
        </div>
    </div>
</footer>

<!-- ════════════════════════════════════════════════════
     JavaScript — Cart, Filter, Wishlist interactions
     ════════════════════════════════════════════════════ -->
<script>
// ── Cart counter ───────────────────────────────────────────────────────────────
let cartCount = 0;
const cartBadge = document.querySelector('.cart-badge');

function addToCart(id, name, btn) {
    cartCount++;
    cartBadge.textContent = cartCount;
    // Visual feedback
    btn.textContent = '✓';
    btn.style.background = 'var(--green-bright)';
    setTimeout(() => {
        btn.textContent = '+';
        btn.style.background = 'var(--green-dark)';
    }, 1200);
}

// ── Category filter ────────────────────────────────────────────────────────────
function filterProducts(category, chipEl) {
    // Update active chip
    document.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('active'));
    chipEl.classList.add('active');

    // Show/hide product cards
    document.querySelectorAll('.product-card').forEach(card => {
        const match = category === 'All Items' || card.dataset.category === category;
        card.style.display = match ? 'flex' : 'none';
    });
}

// ── Wishlist toggle ────────────────────────────────────────────────────────────
function toggleWishlist(btn) {
    btn.classList.toggle('active');
    btn.textContent = btn.classList.contains('active') ? '❤️' : '🤍';
}

// ── Mobile hamburger ───────────────────────────────────────────────────────────
document.getElementById('hamburgerBtn').addEventListener('click', function () {
    const nav = document.querySelector('.navbar-nav');
    nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
    nav.style.position = 'absolute';
    nav.style.top = '72px';
    nav.style.left = '0';
    nav.style.right = '0';
    nav.style.background = '#fff';
    nav.style.padding = '16px 24px';
    nav.style.flexDirection = 'column';
    nav.style.borderBottom = '1px solid var(--border)';
    nav.style.zIndex = '999';
});

// ── Smooth scroll for anchor links ────────────────────────────────────────────
document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
        const target = document.querySelector(a.getAttribute('href'));
        if (target) {
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});
</script>
</body>
</html>
