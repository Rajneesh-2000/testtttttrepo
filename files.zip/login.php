<?php
/**
 * login.php — User Login Page
 * Validates credentials against the database using password_verify().
 * Uses prepared statements to prevent SQL injection.
 */

session_start();

// If already logged in, redirect to homepage
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'db.php';  // Database connection

// ─── Variables ────────────────────────────────────────────────────────────────
$error   = '';
$success = '';
$email   = '';  // Preserve email on failed login

// ─── Check for flash messages from register.php ───────────────────────────────
if (isset($_SESSION['flash_success'])) {
    $success = $_SESSION['flash_success'];
    unset($_SESSION['flash_success']);
}

// ─── Handle POST Submission ───────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email    = trim(strip_tags($_POST['email']    ?? ''));
    $password = trim($_POST['password']            ?? '');

    // ── Basic validation ─────────────────────────────────────────────────────
    if (empty($email) || empty($password)) {
        $error = 'Please enter both your email and password.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        // ── Look up user by email (prepared statement) ───────────────────────
        $stmt = $conn->prepare(
            "SELECT id, name, email, password FROM users WHERE email = ? LIMIT 1"
        );
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user   = $result->fetch_assoc();
        $stmt->close();

        // ── Verify password using password_verify() ──────────────────────────
        if ($user && password_verify($password, $user['password'])) {
            // Credentials valid — regenerate session ID to prevent fixation
            session_regenerate_id(true);

            // Store user info in session
            $_SESSION['user_id']    = $user['id'];
            $_SESSION['user_name']  = $user['name'];
            $_SESSION['user_email'] = $user['email'];

            // Redirect to homepage
            $_SESSION['flash_success'] = 'Welcome back, ' . htmlspecialchars($user['name']) . '! 👋';
            header('Location: index.php');
            exit;
        } else {
            // Generic error — don't reveal which field was wrong (security best practice)
            $error = 'Invalid email or password. Please try again.';
            // Introduce slight delay to deter brute-force
            sleep(1);
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — FreshMart</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🛒</text></svg>">
</head>
<body>

<!-- ════════════════════════════════════════════════════
     AUTH PAGE LAYOUT — Split design
     ════════════════════════════════════════════════════ -->
<div class="auth-page">

    <!-- Left visual panel -->
    <div class="auth-visual">
        <div class="auth-visual-content">
            <span class="auth-visual-emoji">🛒</span>
            <h2>Welcome Back<br>to FreshMart</h2>
            <p>Your favourite fresh groceries are waiting. Log in to pick up where you left off.</p>

            <div class="auth-visual-perks">
                <div class="perk-item">
                    <span class="perk-icon">📦</span>
                    <span>Track your active deliveries</span>
                </div>
                <div class="perk-item">
                    <span class="perk-icon">⭐</span>
                    <span>View your loyalty points balance</span>
                </div>
                <div class="perk-item">
                    <span class="perk-icon">🔁</span>
                    <span>Quickly re-order your favourites</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Right form panel -->
    <div class="auth-form-area">
        <div class="auth-form-box">

            <!-- Logo -->
            <a href="index.php" class="form-logo">
                <div class="logo-icon" style="width:34px;height:34px;background:var(--green-dark);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1rem;">🛒</div>
                FreshMart
            </a>

            <h1>Log In</h1>
            <p class="subtitle">
                Don't have an account?
                <a href="register.php">Sign up free</a>
            </p>

            <!-- ── Success message (e.g. from register redirect) ── -->
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <span class="alert-icon">✅</span>
                    <?= htmlspecialchars($success) ?>
                </div>
            <?php endif; ?>

            <!-- ── Error message ── -->
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <span class="alert-icon">⚠️</span>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <!-- ── Login Form ── -->
            <form method="POST" action="login.php" novalidate id="loginForm">

                <!-- Email -->
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <div class="input-wrap">
                        <span class="input-icon">✉️</span>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            placeholder="john@example.com"
                            value="<?= htmlspecialchars($email) ?>"
                            autocomplete="email"
                            required
                            class="<?= $error ? 'error' : '' ?>"
                        >
                    </div>
                </div>

                <!-- Password -->
                <div class="form-group">
                    <label for="password" style="display:flex;justify-content:space-between;">
                        <span>Password</span>
                        <a href="#" style="font-weight:500;color:var(--green-mid);font-size:0.82rem;">Forgot password?</a>
                    </label>
                    <div class="input-wrap">
                        <span class="input-icon">🔒</span>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Your password"
                            autocomplete="current-password"
                            required
                            class="<?= $error ? 'error' : '' ?>"
                        >
                        <!-- Show/hide password toggle -->
                        <button type="button" id="togglePwd"
                            style="position:absolute;right:14px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:1rem;color:var(--text-light);"
                            title="Show/hide password">
                            👁️
                        </button>
                    </div>
                </div>

                <!-- Remember me -->
                <div style="margin-bottom:24px;display:flex;align-items:center;gap:10px;">
                    <input type="checkbox" name="remember" id="remember"
                        style="width:auto;accent-color:var(--green-dark);cursor:pointer;">
                    <label for="remember" style="font-size:0.85rem;color:var(--text-mid);cursor:pointer;margin:0;">
                        Remember me for 30 days
                    </label>
                </div>

                <!-- Submit -->
                <button type="submit" class="form-submit-btn">
                    🔑 Log In to FreshMart
                </button>

                <div class="divider">or</div>

                <!-- Register link -->
                <div style="text-align:center;">
                    <a href="register.php" class="btn btn-outline" style="width:100%;justify-content:center;">
                        🌱 Create a Free Account
                    </a>
                </div>

            </form>

            <!-- Demo credentials hint (remove in production) -->
            <div style="margin-top:24px;padding:14px;background:var(--green-pale);border-radius:var(--radius-sm);font-size:0.8rem;color:var(--green-mid);">
                <strong>💡 Demo:</strong> Register a new account first, then log in with those credentials.
            </div>

        </div>
    </div>
</div>

<script>
// ── Toggle password visibility ─────────────────────────────────────────────────
document.getElementById('togglePwd').addEventListener('click', function () {
    const pwd = document.getElementById('password');
    const isText = pwd.type === 'text';
    pwd.type = isText ? 'password' : 'text';
    this.textContent = isText ? '👁️' : '🙈';
});

// ── Basic client-side validation ───────────────────────────────────────────────
document.getElementById('loginForm').addEventListener('submit', function (e) {
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    if (!email || !password) {
        e.preventDefault();
        alert('Please fill in all fields.');
    }
});
</script>
</body>
</html>
