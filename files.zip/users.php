<?php
/**
 * users.php — Registered Users Admin Page
 * Displays all users from the `users` table in a clean admin dashboard.
 * In a real app this page should be protected by admin authentication.
 */

session_start();
require_once 'db.php';

// ─── Fetch all users from database ───────────────────────────────────────────
$users      = [];
$user_count = 0;
$latest_user= null;

$result = $conn->query("SELECT id, name, email, created_at FROM users ORDER BY created_at DESC");

if ($result) {
    $user_count  = $result->num_rows;
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    // Most recently registered
    if (!empty($users)) {
        $latest_user = $users[0]['name'];
    }
}

$conn->close();

// ─── Helper: get user initials for avatar ─────────────────────────────────────
function getInitials(string $name): string {
    $words = explode(' ', trim($name));
    $initials = '';
    foreach (array_slice($words, 0, 2) as $word) {
        $initials .= strtoupper($word[0] ?? '');
    }
    return $initials ?: '?';
}

// ─── Helper: time-ago string ──────────────────────────────────────────────────
function timeAgo(string $datetime): string {
    $ts   = strtotime($datetime);
    $diff = time() - $ts;
    if ($diff < 60)   return 'Just now';
    if ($diff < 3600) return floor($diff/60) . ' min ago';
    if ($diff < 86400)return floor($diff/3600) . ' hr ago';
    if ($diff < 604800)return floor($diff/86400) . ' days ago';
    return date('d M Y', $ts);
}

$hostname = gethostname();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registered Users — FreshMart Admin</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>👥</text></svg>">
</head>
<body>

<!-- ════════════════════════════════════════════════════
     ADMIN PAGE LAYOUT
     ════════════════════════════════════════════════════ -->
<div class="admin-page">

    <!-- ── Admin Header ── -->
    <header class="admin-header">
        <div class="container">
            <div class="admin-header-inner">
                <a href="index.php" class="logo">
                    <div class="logo-icon">🛒</div>
                    FreshMart Admin
                </a>
                <nav style="display:flex;align-items:center;gap:8px;">
                    <a href="index.php">← Back to Store</a>
                    <a href="register.php">Register</a>
                    <a href="login.php">Login</a>
                </nav>
            </div>
        </div>
    </header>

    <!-- ── Admin Content ── -->
    <main class="admin-content">
        <div class="container">

            <!-- Page title -->
            <div style="margin-bottom:32px;">
                <h1 class="section-title">Registered Users</h1>
                <p class="section-subtitle">
                    All accounts stored in the <code style="background:var(--green-pale);padding:2px 8px;border-radius:4px;color:var(--green-dark);font-size:0.85rem;">users</code>
                    table on <code style="background:var(--green-pale);padding:2px 8px;border-radius:4px;color:var(--green-dark);font-size:0.85rem;"><?= htmlspecialchars($hostname) ?></code>
                </p>
            </div>

            <!-- Stats cards -->
            <div class="admin-stats">
                <div class="stat-card">
                    <div class="stat-card-icon">👥</div>
                    <div>
                        <div class="stat-card-num"><?= $user_count ?></div>
                        <div class="stat-card-label">Total Registered Users</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-card-icon">🆕</div>
                    <div>
                        <div class="stat-card-num" style="font-size:1.1rem;margin-top:4px;">
                            <?= $latest_user ? htmlspecialchars($latest_user) : '—' ?>
                        </div>
                        <div class="stat-card-label">Most Recent Registration</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-card-icon">🗄️</div>
                    <div>
                        <div class="stat-card-num" style="font-size:1rem;margin-top:6px;">grocery_db</div>
                        <div class="stat-card-label">MySQL Database</div>
                    </div>
                </div>
            </div>

            <!-- Users Table Card -->
            <div class="table-card">

                <!-- Card header -->
                <div class="table-card-header">
                    <h2>👤 All Users</h2>
                    <div style="display:flex;align-items:center;gap:12px;">
                        <span style="font-size:0.85rem;color:var(--text-light);">
                            <?= $user_count ?> record<?= $user_count !== 1 ? 's' : '' ?> found
                        </span>
                        <a href="register.php" class="btn btn-primary" style="padding:8px 18px;font-size:0.85rem;">
                            + Add User
                        </a>
                    </div>
                </div>

                <!-- Table -->
                <?php if (empty($users)): ?>
                    <!-- Empty state -->
                    <div class="empty-state">
                        <div class="empty-icon">📭</div>
                        <p><strong>No users registered yet.</strong></p>
                        <p style="margin-top:8px;">
                            <a href="register.php" class="btn btn-primary" style="margin-top:16px;display:inline-flex;">
                                Register First User
                            </a>
                        </p>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th style="width:56px;">#ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Registered</th>
                                <th>Time Ago</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                            <tr>
                                <!-- ID -->
                                <td class="td-id">#<?= (int) $user['id'] ?></td>

                                <!-- Name with avatar -->
                                <td>
                                    <div class="user-cell">
                                        <div class="user-avatar">
                                            <?= htmlspecialchars(getInitials($user['name'])) ?>
                                        </div>
                                        <span class="td-name"><?= htmlspecialchars($user['name']) ?></span>
                                    </div>
                                </td>

                                <!-- Email -->
                                <td class="td-email">
                                    <a href="mailto:<?= htmlspecialchars($user['email']) ?>">
                                        <?= htmlspecialchars($user['email']) ?>
                                    </a>
                                </td>

                                <!-- Created at (formatted) -->
                                <td class="td-date">
                                    <?= date('d M Y, H:i', strtotime($user['created_at'])) ?>
                                </td>

                                <!-- Time ago (human-readable) -->
                                <td>
                                    <span class="tag tag-green">
                                        <?= htmlspecialchars(timeAgo($user['created_at'])) ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>

            </div><!-- /table-card -->

            <!-- Note about password security -->
            <div style="margin-top:20px;padding:16px 20px;background:#fff;border:1px solid var(--border);border-radius:var(--radius-sm);font-size:0.85rem;color:var(--text-mid);display:flex;gap:10px;align-items:flex-start;">
                <span style="font-size:1.1rem;">🔐</span>
                <span>
                    <strong>Security note:</strong> Passwords are stored as bcrypt hashes (via <code>password_hash()</code>) — 
                    the actual passwords are never stored in plain text. This table is intentionally omitted from this view.
                </span>
            </div>

        </div><!-- /container -->
    </main>

    <!-- ── Mini footer ── -->
    <footer style="background:var(--text-dark);color:rgba(255,255,255,0.5);text-align:center;padding:20px;font-size:0.8rem;">
        FreshMart Admin &bull; Server: <?= htmlspecialchars($hostname) ?> &bull; PHP <?= phpversion() ?>
    </footer>

</div>

</body>
</html>
